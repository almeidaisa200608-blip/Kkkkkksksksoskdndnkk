// Também permite virar o cartão com toque em celulares.
document.querySelectorAll('.cartao').forEach((cartao) => {
  cartao.setAttribute('tabindex', '0');
  cartao.setAttribute('role', 'button');
  cartao.setAttribute('aria-label', 'Virar cartão para ver a resposta');

  cartao.addEventListener('click', (event) => {
    // Em telas com mouse, o hover já mostra o verso; o clique alterna o estado.
    cartao.classList.toggle('virado');
  });

  cartao.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      cartao.classList.toggle('virado');
    }
  });
});
